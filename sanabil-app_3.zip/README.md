# سنابل — تطبيق توزيع الطحين (PWA)
1. أنشئ مستودعاً على GitHub وارفع كل الملفات (بما فيها مجلد `.github`).
2. Settings ← Pages ← Source: **GitHub Actions**، ثم انتظر النشر.
3. افتح الرابط من الهاتف ← «إضافة إلى الشاشة الرئيسية».
4. من الإعدادات: استعد نسخة البيانات، أدخل رابط Google Sheets، ورمز بوت Telegram الجديد ومعرّف الدردشة.
⚠️ لا ترفع ملفات النسخ الاحتياطية (أسماء المواطنين) إلى مستودع عام.

## صيغة الطلبات إلى Google Apps Script
POST (text/plain, JSON): `{action:'delivery'|'syncAll', ...}` — GET: `?action=ping` و `?action=restore` (يُرجع `{families,dist}`).
